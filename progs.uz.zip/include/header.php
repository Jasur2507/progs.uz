<?php header("Content-type: text/html; charset=windows-1251"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap 4 Website Example</title>
  <meta http-equiv="Content-Type" content="text/html"; charset="windows-1251" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <script src="https://cdn.tiny.cloud/1/7yjjwzs8un4qes0u5aoyaheg173nh8n1mlmwb4e66ft867ek/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
  <style>
  .fakeimg {
    height: 200px;
    background: #aaa;
  }
  </style>
</head>
<body>
  <div class="container">
<div class="d-flex">
    <div class="p-2 ml-3" style="font-size:30px;"><a href="/">PROGS.UZ</a></div>
    <div class="p-3 ml-auto">Resize this responsive page to see the effect!</div>
</div>
